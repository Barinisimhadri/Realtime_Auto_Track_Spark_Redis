# auto-tracking
Demonstration of how to use Redis key-value database to power an real-time auto-tracking system.
